package com.example.a411202113_rioanes;

package com.example.menuapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class CartActivity extends AppCompatActivity {

    private List<CartItem> cartItems = new ArrayList<>();
    private TextView totalText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        totalText = findViewById(R.id.textTotal);

        // Dummy data
        cartItems.add(new CartItem("Noodles", 15000, 1, R.drawable.noodles));
        cartItems.add(new CartItem("Beef Burger", 25000, 1, R.drawable.beef_burger));

        // Update total
        updateTotal();

        // Checkout button
        findViewById(R.id.btnCheckout).setOnClickListener(v -> {
            Toast.makeText(this, "Checkout successful!", Toast.LENGTH_SHORT).show();
        });
    }

    private void updateTotal() {
        int total = 0;
        for (CartItem item : cartItems) {
            total += item.getPrice() * item.getQuantity();
        }
        totalText.setText("Rp. " + total);
    }
}

