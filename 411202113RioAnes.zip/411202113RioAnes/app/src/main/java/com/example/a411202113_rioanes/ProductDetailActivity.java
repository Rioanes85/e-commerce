package com.example.a411202113_rioanes;

package com.example.menuapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ProductDetailActivity extends AppCompatActivity {

    private int quantity = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        // Inisialisasi elemen
        TextView quantityText = findViewById(R.id.textQuantity);
        ImageView btnAdd = findViewById(R.id.btnAdd);
        ImageView btnMinus = findViewById(R.id.btnMinus);

        // Tombol tambah kuantitas
        btnAdd.setOnClickListener(v -> {
            quantity++;
            quantityText.setText(String.valueOf(quantity));
        });

        // Tombol kurangi kuantitas
        btnMinus.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                quantityText.setText(String.valueOf(quantity));
            } else {
                Toast.makeText(this, "Minimum quantity is 1", Toast.LENGTH_SHORT).show();
            }
        });

        // Tombol "Add to Cart"
        findViewById(R.id.btnAddToCart).setOnClickListener(v -> {
            Toast.makeText(this, "Added to Cart!", Toast.LENGTH_SHORT).show();
        });
    }
}

